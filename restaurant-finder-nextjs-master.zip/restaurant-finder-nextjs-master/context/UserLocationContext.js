const { createContext } = require("react");

export const UserLocationContext=createContext(null)