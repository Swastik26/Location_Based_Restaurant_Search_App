const { createContext } = require("react");

export const SelectedBusinessContext=createContext(null)